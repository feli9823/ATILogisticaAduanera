import flet as ft
from views.dashboard import layoutPrincipal


# ─────────────────────────────────────────────
#  Colores internos
# ─────────────────────────────────────────────
tableHeaderBg = "#1A1A2E"
tableRowBg    = "#1E1E2E"
tableRowAlt   = "#252535"
borderColor   = "#2A2A3E"
accentColor   = "#CBA6F7"
btnAddBg      = "#CBA6F7"
btnAddText    = "#121212"



def reporte(router) -> ft.Control:
    contenedor = ft.Container(
        expand=True,
        bgcolor="#E0E0E0",
        alignment=ft.Alignment.CENTER,
        content=ft.Text(
            "Reporte de ventas",
            size=28,
            weight=ft.FontWeight.BOLD,
            color="#333333",
        ),
    )
    return layoutPrincipal(router, contenedor, activePage="reporte")