#Archivo de constantes para estilos y colores


BG_COLOR    = "#121212"   # fondo principal oscuro
TEXT_COLOR  = "#FFFFFF"   # texto blanco    
BTN_BG      = "#FFFFFF"   # fondo del botón
BTN_TEXT    = "#121212"   # texto del botón 



# ─────────────────────────────────────────────
#  Colores internos
# ─────────────────────────────────────────────
tableHeaderBg = "#1A1A2E"
tableRowBg    = "#1E1E2E"
tableRowAlt   = "#252535"
borderColor   = "#2A2A3E"
accentColor   = "#CBA6F7"
btnAddBg      = "#CBA6F7"
btnAddText    = "#121212"

