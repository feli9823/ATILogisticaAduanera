def validarPrecio(precio):
    try:
        if precio != float(precio):
            raise ValueError("El precio debe ser un número.")
        precio = float(precio)
        if precio < 0:
            raise ValueError("El precio no puede ser negativo.")
    except ValueError as e:
        print(f"Error: {e}")
        return False
    return True


def validarNombre(nombre):
    if not isinstance(nombre, str) or not nombre.strip():
        print("Error: El nombre del producto debe ser una cadena no vacía.")
        return False
    return True