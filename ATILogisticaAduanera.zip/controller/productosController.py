from model import productos as ProductosModel
from validation import productosValidador

_modeloProductos = ProductosModel.productos()


def guardarProducto(nombre: str, precio: float) -> dict | None:
    
    if not productosValidador.validarNombre(nombre):
        return None
    if not productosValidador.validarPrecio(precio):
        return None

    exito = _modeloProductos.agregarProducto(nombre, precio)
    if exito:
        nuevoId = len(_modeloProductos.lista_productos)
        return {
            "id"    : nuevoId,
            "nombre": nombre,
            "precio": precio,
        }
    return None

def modificarProducto(id: int, nombre: str = None, precio: float = None) -> bool:
    """
    Modifica un producto existente por id.
    Retorna True si se modificó, False si no existía.
    """
    if id not in _modeloProductos.lista_productos:
        return False

    if nombre and not productosValidador.validarNombre(nombre):
        return False
    if precio and not productosValidador.validarPrecio(precio):
        return False

    _modeloProductos.modificarProducto(id, nombre=nombre, precio=precio)
    return True



def eliminarProducto(id: int) -> bool:
    """
    Elimina un producto por id.
    Retorna True si se eliminó, False si no existía.
    """
    if id not in _modeloProductos.lista_productos:
        return False

    _modeloProductos.eliminarProducto(id)
    return True


def obtenerProductos() -> list[dict]:
    """
    Retorna todos los productos para mostrar en la tabla.
    Formato: [{"id": 1, "nombre": "...", "precio": 0.0}, ...]
    """
    datos = _modeloProductos.mostrarProductos()
    return [
        {
            "id"    : id,
            "nombre": p["nombre"],
            "precio": p["precio"],
        }
        for id, p in datos.items()
    ]


