from model import pais as PaisModel
from validation import paisValidador

# ─────────────────────────────────────────────
#  Instancia única del modelo (Singleton)
# ─────────────────────────────────────────────
_modeloPais = PaisModel.pais()


# ─────────────────────────────────────────────
#  Guardar país (RF-10)
# ─────────────────────────────────────────────
def guardarPais(nombre: str, tarifaImpuesto: float, tipoMoneda: str) -> dict | None:
    """
    Valida y guarda un nuevo país.
    Retorna el país creado como dict o None si falló.
    """
    if not paisValidador.validarNombre(nombre):
        return None
    if not paisValidador.validarTarifa(tarifaImpuesto):
        return None
    if not paisValidador.validarMoneda(tipoMoneda):
        return None

    exito = _modeloPais.agregarPais(nombre, tarifaImpuesto, tipoMoneda)
    if exito:
        nuevoId = len(_modeloPais.listaPais)
        return {
            "id"             : nuevoId,
            "nombre"         : nombre,
            "tarifaImpuesto" : tarifaImpuesto,
            "tipoMoneda"     : tipoMoneda,
        }
    return None


# ─────────────────────────────────────────────
#  Modificar país
# ─────────────────────────────────────────────
def modificarPais(id: int, nombre: str = None, tarifaImpuesto: float = None, tipoMoneda: str = None) -> bool:
    """
    Modifica un país existente por id.
    Retorna True si se modificó, False si no existía o datos inválidos.
    """
    if id not in _modeloPais.listaPais:
        return False
    if nombre is not None and not paisValidador.validarNombre(nombre):
        return False
    if tarifaImpuesto is not None and not paisValidador.validarTarifa(tarifaImpuesto):
        return False
    if tipoMoneda is not None and not paisValidador.validarMoneda(tipoMoneda):
        return False

    _modeloPais.modificarPais(id, nombre=nombre, tarifaImpuesto=tarifaImpuesto, tipoMoneda=tipoMoneda)
    return True


# ─────────────────────────────────────────────
#  Eliminar país
# ─────────────────────────────────────────────
def eliminarPais(id: int) -> bool:
    """
    Elimina un país por id.
    Retorna True si se eliminó, False si no existía.
    """
    if id not in _modeloPais.listaPais:
        return False
    _modeloPais.eliminarPais(id)
    return True


# ─────────────────────────────────────────────
#  Obtener todos los países
# ─────────────────────────────────────────────
def obtenerPaises() -> list[dict]:
    """
    Retorna todos los países para mostrar en la tabla.
    Formato: [{"id": 1, "nombre": "...", "tarifaImpuesto": 0.0, "tipoMoneda": "USD"}, ...]
    """
    datos = _modeloPais.mostrarPais()
    return [
        {
            "id"             : id,
            "nombre"         : p["nombre"],
            "tarifaImpuesto" : p["tarifaImpuesto"],
            "tipoMoneda"     : p["tipoMoneda"],
        }
        for id, p in datos.items()
    ]

